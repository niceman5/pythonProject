#!/usr/bin/env python
import cgi

cgi.test()
