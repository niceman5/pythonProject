#!/usr/local/bin/python3

import cgitb; cgitb.enable()
import sys
import codecs

writer = codecs.getwriter('utf-8')(sys.stdout.buffer)

print ("Content-Type: text/html;charset=utf-8\n", file=writer)

print(a)    # a is not defined
