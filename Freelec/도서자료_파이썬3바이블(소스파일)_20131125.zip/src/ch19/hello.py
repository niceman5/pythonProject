#!/usr/local/bin/python3

print("Content-Type: text/html\n\n")

print('''
<HTML>
<HEAD></HEAD>
<BODY>
Hello world
</BODY>
</HTML>''')
