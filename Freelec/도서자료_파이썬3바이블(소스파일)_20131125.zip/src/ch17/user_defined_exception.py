# user_defined_exception.py

import sys

class Big(Exception):
    pass

class Small(Big):
    pass

def dosomething1():
    raise Big('big excpetion')		# 예외가 발생한다.

def dosomething2():
    raise Small('small exception')

for f in (dosomething1, dosomething2):
    try:
        f()
    except Big:
        print(sys.exc_info())
