#!/usr/bin/env python
import sys
from lib2to3.main import main
import glob

sys.argv[2:] = glob.glob('*.py')
print(sys.argv)

sys.exit(main("lib2to3.fixes"))
