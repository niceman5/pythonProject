print('A1')
import B

print('A2')
a = 10
print(B.b)