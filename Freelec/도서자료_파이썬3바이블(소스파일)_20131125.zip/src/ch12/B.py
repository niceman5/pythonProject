print('B1')
import A

print('B2')
b = 20
#print(A.a)     # error