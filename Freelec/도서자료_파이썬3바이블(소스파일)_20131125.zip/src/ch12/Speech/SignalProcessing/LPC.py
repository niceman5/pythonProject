#file : LPC.py

class LinearPrediction:
    pass
