# turtle01.py
import turtle

turtle.tracer(False)
t1 = turtle.Turtle()

screen = t1.getscreen()
w = 150
screen.setworldcoordinates(-w, -w, w, w)
for i in range(200):
    t1.forward(i)
    t1.left(90.5)

turtle.tracer(True)
t1.hideturtle()
turtle.done()
