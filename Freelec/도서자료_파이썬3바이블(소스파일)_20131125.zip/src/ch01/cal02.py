# file : cal02.py
import calendar
calendar.setfirstweekday(6)  # 일요일을 첫 요일로..
calendar.prmonth(2012, 6)
input()    # 키보드 입력받는 명령
