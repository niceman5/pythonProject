#!/usr/bin/env python3
# file : cal03.py
import calendar

calendar.setfirstweekday(6)  # 일요일을 첫 요일로..
calendar.prmonth(2012, 6)
