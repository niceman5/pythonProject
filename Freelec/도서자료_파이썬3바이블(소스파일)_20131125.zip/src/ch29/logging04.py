# logging04.py
import logging
import mymath

logging.basicConfig(
    level=logging.DEBUG, 
    format='%(asctime)s:%(message)s',
    datefmt='%Y/%m/%d %H:%M:%S')
logging.info('debug message')
mymath.add(2,3)
