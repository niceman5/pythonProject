# division.py

def division(a,b):
    return a/b

if __name__ == '__main__':    
    division(5, 0)
