# logging01.py
import logging

logging.basicConfig(level=logging.INFO)
logging.debug('debug message')
logging.info('info message')
