# test_unittest03.py 
import unittest  

def suite():
    return unittest.defaultTestLoader.loadTestsFromNames(
        ('test_unittest01','test_unittest02')
    )

if __name__=='__main__':  
    unittest.main(argv=['','-v','suite'])
