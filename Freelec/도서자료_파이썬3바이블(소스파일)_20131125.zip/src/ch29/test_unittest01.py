# test_unittest01.py
import unittest

class MyTestCase(unittest.TestCase):
    def test_sample(self):  # 기본 테스트 메써드
        self.assertEqual( (3 * 4), 11)	# 실패할 테스트. 12 와 11은 다르다

if __name__ == '__main__':
    unittest.main()
    #unittest.main(argv=['', '-v'])
