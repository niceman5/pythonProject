# mymath.py
import logging

def add(a,b):
    logging.debug('adding {} + {}'.format(a, b))
    return a+b
