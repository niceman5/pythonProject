from distutils.core import setup, Extension

setup(name="square", 
      version="1.0",
      description="type extension module",
      author="Lee, Gang Seong",
      author_email="gslee0115@gmail.com",
      url="http://pythonworld.net/",
      ext_modules=[
         Extension("square", ["square.c"]),
         ]
)
